const mysql = require("mysql2");

exports.handler = async (event) => {
    // TODO implement
    console.log(event.body)
    const buyer = event.body.data.object.metadata.buyer
    const list = event.body.data.object.metadata.list
    const connection = mysql.createConnection(process.env.DATABASE_URL);
    var [result, fields, err] = await connection
        .promise()
        .query(
          `INSERT INTO purchased_lists (list_id, buyer_id) VALUES "${list}", "${buyer}";`
        );
    connection.close();
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
